package com.java.Basics;




class A {
	static int a = 10 ;
}

final class C {
	
}

//class D extends C {
//	
//}


public class FinalBasicsAllAboutIt extends A{
	
	public static void main(String[] args) {
//		char a = 'a';
		char b= 'b';
		int c = a;
		int d = 195;
		System.out.println(c+b);
		System.out.println((char)d);
		
		C cc = new C();
		
	}

}
