package com.java.Basics;

public class StringBasics {
	
	char s;
	public static void main(String[] args) {
		
		String s1 = "Mima";
		String s2 = "Mima";
		String s3 = new String("Mima");
		String s4 = new String("Mima");
		
		System.out.println( s1==s2 );
		
		System.out.println(s1==s3);
		
		System.out.println(s3==s4);
		

//		char s;
//		String sa;
//		int r;
//		byte b;
		
		StringBasics aa = new StringBasics();
		
		System.out.println(aa.s);
//		System.out.println(sa);
//		System.out.println(r);
//		System.out.println(s);
		
	}

}
