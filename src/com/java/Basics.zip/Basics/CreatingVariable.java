package com.java.Basics;

public class CreatingVariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int A;
//		// System.out.println(A); // not applicable
//		A = 12;
//		System.out.println(A); // Valid
//		
//		int a = 10 ;
//		short s = 15 ;
//		long l = 117 ;
//		double i = 10.5 ;
//		float f = 10.5f ;
//		
//		char ch = 'a';
//		boolean b1 = false;
//		int isValid;
//      # use CAMEL Case
//      isCamel
//      isValid
		byte b = 10 ;
//		byte d = 130 ; 
		System.out.println(b);
		
	}

}
