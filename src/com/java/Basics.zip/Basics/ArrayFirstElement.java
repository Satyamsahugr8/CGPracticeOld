package com.java.Basics;

public class ArrayFirstElement {
	static int a = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []	arr=	{10,20,30,40,50,34,343,232,1,21,23434,5,454};
			for (int i:arr) //forEach
			{
			System.out.print(i+" ");
			}
			System.out.println("");
			System.out.print(a);
			
		}
	}


