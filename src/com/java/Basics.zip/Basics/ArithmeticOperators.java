package com.java.Basics;

public class ArithmeticOperators {

	public static void main(String[] args) {
		
		
		// [ + , - , * , / , % ]
 		int a = 10 , b = 3 , c = 10 / 3 ;// integral value
 		
		int d = 10 % 3 ; // remainder
		
		double C = 10 / 30 ; // so here nothing gonno change here bec. 
		// the execution take place from right hand side 
		// so the value is of type integer on the right so 
		// the answer is in type integer but after that it is changed 
		// to double type.
		System.out.println(c);
		System.out.println(d);
		System.out.println(C); // double 
	}

}
